globalThis.sloppyPrecompressed = true;
